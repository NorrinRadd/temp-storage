DO NOT MODIFY THE CONTENTS OF THIS DIRECTORY

Any adjustment to bundled fonts will result in an altered fingerprint. Font
fingerprinting is more than just detecting what fonts you have, it also includes
font fallbacks and characters (Unicode code points) and any change in those can
be measured.
